package com.example.chapter0203kotlin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // 宣告元件變數 (使用 lateinit 延遲初始化)
    private lateinit var edName: EditText
    private lateinit var tvText: TextView
    private lateinit var tvName: TextView
    private lateinit var tvWinner: TextView
    private lateinit var tvMmora: TextView
    private lateinit var tvCmora: TextView
    private lateinit var btnScissor: RadioButton
    private lateinit var btnStone: RadioButton
    private lateinit var btnPaper: RadioButton
    private lateinit var btnMora: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 連結 XML 中的元件 ID
        edName = findViewById(R.id.ed_name)
        tvText = findViewById(R.id.tv_text)
        tvName = findViewById(R.id.tv_name)
        tvWinner = findViewById(R.id.tv_winner)
        tvMmora = findViewById(R.id.tv_mmora)
        tvCmora = findViewById(R.id.tv_cmora)
        btnScissor = findViewById(R.id.btn_scissor)
        btnStone = findViewById(R.id.btn_stone)
        btnPaper = findViewById(R.id.btn_paper)
        btnMora = findViewById(R.id.btn_mora)

        // 設定按鈕點擊監聽事件
        btnMora.setOnClickListener {
            // 判斷玩家是否輸入姓名
            if (edName.length() < 1) {
                tvText.text = "請輸入玩家姓名"
            } else {
                val playerName = edName.text.toString()

                // Kotlin 字串模板 (String Template) 範例：直接用 $變數 代替字串串接
                tvName.text = "名字\n$playerName"

                // 判斷我方出拳
                if (btnScissor.isChecked) {
                    tvMmora.text = "我方出拳\n剪刀"
                } else if (btnStone.isChecked) {
                    tvMmora.text = "我方出拳\n石頭"
                } else {
                    tvMmora.text = "我方出拳\n布"
                }

                // 亂數產生電腦出拳 (0~2)
                val computerRandom = (Math.random() * 3).toInt()

                // 顯示電腦出拳
                if (computerRandom == 0) {
                    tvCmora.text = "電腦出拳\n剪刀"
                } else if (computerRandom == 1) {
                    tvCmora.text = "電腦出拳\n石頭"
                } else {
                    tvCmora.text = "電腦出拳\n布"
                }

                // 判斷勝負邏輯
                if ((btnScissor.isChecked && computerRandom == 2) ||
                    (btnStone.isChecked && computerRandom == 0) ||
                    (btnPaper.isChecked && computerRandom == 1)) {
                    tvWinner.text = "勝利者\n$playerName"
                    tvText.text = "恭喜您贏了!!!"
                } else if ((btnScissor.isChecked && computerRandom == 1) ||
                    (btnStone.isChecked && computerRandom == 2) ||
                    (btnPaper.isChecked && computerRandom == 0)) {
                    tvWinner.text = "勝利者\n電腦"
                    tvText.text = "可惜,電腦贏了獲勝了!"
                } else {
                    tvWinner.text = "勝利者\n平手"
                    tvText.text = "平局,請再試一次!"
                }
            }
        }
    }
}